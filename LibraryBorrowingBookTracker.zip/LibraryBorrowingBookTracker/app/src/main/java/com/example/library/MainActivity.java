package com.example.library;

import android.database.Cursor;   //to call out and read db results
import android.os.Bundle;   //carries saved info when android starts/runs

//now importing the xml here in MainActivity
import android.widget.ArrayAdapter;   //connects arraylist to listview
import android.widget.Button;   //use buttons
import android.widget.EditText;   //use text boxes
import android.widget.ListView;   //use the list from the xml
import android.widget.Toast;   //allows to show some text msg long or short

//the grey ones is we dont needed, it just there cuz it auto when created a java file
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    //putting all the xml ui here at the functions
    //these are the text boxes from the xml
    EditText bookInput;
    EditText studentNameInput;
    EditText studentIDInput;
    EditText searchInput;

    //buttons category are here, it represents
    Button searchButton;
    Button addButton;
    Button showButtons;

    //Lists of borrowed books here
    ListView bookList;

    //creates an object that will call the DatabaseHelper file
    DatabaseHelper databaseHelper;

    //holds the book info that need to display, but needed to connect into listview
    ArrayList<String> bookData;

    //adapter can connect arraylist to the listview
    ArrayAdapter<String> adapter;

    //its like a main method, this is the first method to run
    //plan is to put ui, db, buttons...
    @Override
    protected void onCreate(Bundle savedInstanceState){
        //letting android perform normally
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);   //calling to xml file(ui)

        //finding the id (android:id=@+id in xml) and puts inside the java variable
        //its like java can now control all of this, which we can input/use scanner
        bookInput = findViewById(R.id.bookInput);
        studentNameInput = findViewById(R.id.studentNameInput);
        studentIDInput = findViewById(R.id.studentIDInput);
        searchInput = findViewById(R.id.searchInput);

        //same thing as java can control and gives it function
        addButton = findViewById(R.id.addButton);
        searchButton = findViewById(R.id.searchButton);
        showButtons = findViewById(R.id.showButtons);
        //java gets the list
        bookList = findViewById(R.id.bookList);

        //it connects this screen to the database file
        databaseHelper = new DatabaseHelper(this);

        //create an object that can store this info to the listview
        bookData = new ArrayList<>();
        //creates a bridge between bookData and the listview
        //simple_list_item_1 is and android design for displaying one line of text
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookData);

        //telling the arraylist to use the "adapter"
        bookList.setAdapter(adapter);
        addButton.setOnClickListener(v -> {
            String book = bookInput.getText().toString().trim();
            String student = studentNameInput.getText().toString().trim();
            String studentID = studentIDInput.getText().toString().trim();

            if (book.isEmpty() || student.isEmpty() || studentID.isEmpty()){
                Toast.makeText(MainActivity.this, "Please fill in the form", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = databaseHelper.addBook(book, student, studentID);
            if (success){
                Toast.makeText(MainActivity.this, "Book Borrowed Successfully", Toast.LENGTH_SHORT).show();

                bookInput.setText("");
                studentNameInput.setText("");
                studentIDInput.setText("");

                displayBooks();

            }else{
                Toast.makeText(MainActivity.this, "Failed Saved Book", Toast.LENGTH_SHORT).show();
            }
        });

        showButtons.setOnClickListener(v -> {
            displayBooks();
        });
        displayBooks();
    }

    private void displayBooks(){
        Cursor cursor = databaseHelper.getAllBooks();
        bookData.clear();

        while (cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String book = cursor.getString(cursor.getColumnIndexOrThrow("book_title"));
            String student = cursor.getString(cursor.getColumnIndexOrThrow("student_name"));
            String studentID = cursor.getString(cursor.getColumnIndexOrThrow("student_id"));
            String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
            String result = id + " | " + book + " | " + student + " | " + studentID + " | " + status;

            bookData.add(result);
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void searchBooks(String search){
        Cursor cursor = databaseHelper.searchBook(search);

        bookData.clear();

        while(cursor.moveToNext()){
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String book = cursor.getString(cursor.getColumnIndexOrThrow("book_title"));
            String student = cursor.getString(cursor.getColumnIndexOrThrow("student_name"));
            String studentID = cursor.getString(cursor.getColumnIndexOrThrow("student_id"));
            String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
            String result = id + " | " + book + " | " + student + " | " + studentID + " | " + status;

            bookData.add(result);
        }
        cursor.close();
        adapter.notifyDataSetChanged();
//        // Initialize Database
//        databaseHelper = new DatabaseHelper(this);
//
//        // Initialize UI Elements
//        bookInput = findViewById(R.id.bookInput);
//        studentNameInput = findViewById(R.id.studentNameInput);
//        stduentIDInput = findViewById(R.id.stduentIDInput);
//        addButton = findViewById(R.id.addButton);
//        bookList = findViewById(R.id.bookList);
//
//        // Initialize List and Adapter
//        listItem = new ArrayList<>();
//        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItem);
//        bookList.setAdapter(adapter);
    }
}



//our goal is to control, edit, functions the emulator(android app). giving it life
// and import the db and xml here at this file