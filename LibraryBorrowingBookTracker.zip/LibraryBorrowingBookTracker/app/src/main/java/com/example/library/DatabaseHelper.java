package com.example.library;

import android.content.ContentValues;   /*this is like a container of what we need to put
in our database*/
import android.content.Context;   /*gives an access to the android app*/
import android.database.Cursor;   /*going thru the information that sqlite gives back*/
import android.database.sqlite.SQLiteDatabase;   /*java communicate with sqlite database*/
import android.database.sqlite.SQLiteOpenHelper;   /*let us create and manage the database,
so that we dont have to build everything from scratch*/

//DatabaseHelper is responsible for managing the SQLite database
public class DatabaseHelper extends SQLiteOpenHelper{
    //gives the database a name
    private static final String DATABASE_NAME = "Library.db";
    private static final int DATABASE_VERSION = 1;   //tells the android which database version im using
    private static final String TABLE_BOOKS = "books";
    private static final String COLUMN_ID = "id";   //records its own number
    private static final String COLUMN_BOOK = "book_title";
    private static final String COLUMN_STUDENT = "student_name";
    private static final String COLUMN_STUDENT_ID = "student_id";
    private static final String COLUMN_STATUS = "status";   //this stores whether the book is returned

    //a constructor
    //receives the android app context or funcitons so that it can work
    public DatabaseHelper(Context context){
        //sends the database info to sqlitehelper, this means using this app, database name and database version
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //runs when database created for the first time
    //the db object is the database
    @Override
    public void onCreate(SQLiteDatabase db){
        //sql commands for making our table just like in the display on xml
        //using java operators
        //column_id + inteber primary key autoincement is saying that it gets the list of 1, 2 ,3...
        //text meaning it creates a column and stores the text/input
        String createTable = "CREATE TABLE " + TABLE_BOOKS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_BOOK + " TEXT, " +
                COLUMN_STUDENT + " TEXT, " +
                COLUMN_STUDENT_ID + " TEXT, " +
                COLUMN_STATUS + " TEXT)";
        //this is important for it to run
        //this tells the sqlite to run the sql commands, wihtout it we cant execute
        db.execSQL(createTable);
    }

    //creating for when increasing the db version, it is used so that we can change the structure of the db
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        //this deletes the old table, and this can delete the data
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);

        //when deleting the old data, it creates a new one, call in the onCreate Method at 31
        onCreate(db);
    }

    //saves a new book method, the values on the parameters are info coming from the MainActivity (java functions)
    public boolean addBook(String book, String student, String studentID){
        SQLiteDatabase db = this.getWritableDatabase();   //opens the db, so that can change or add info
        ContentValues values = new ContentValues();   //creates a empty like box object (values) so that we put our info before saving

        //this is the box of the contentvalues, and we can put the info here before saving on db
        values.put(COLUMN_BOOK, book);
        values.put(COLUMN_STUDENT, student);
        values.put(COLUMN_STUDENT_ID, studentID);
        values.put(COLUMN_STATUS, "Borrowed");   //it automatics when newly book will be borrowed not returned yet

        //puts the info into the "books" table, this can give a number whether the insert works
        long result = db.insert(TABLE_BOOKS, null, values);
        //this returns will be true is saving worked
        return result != -1;
    }

    //gets all the books, using Cursor becuz the reuslts contain multipls rows
    public Cursor getAllBooks(){
        //opens the db for reading only
        SQLiteDatabase db = this.getReadableDatabase();

        //giving everything inside the books table
        return db.rawQuery("SELECT * FROM " + TABLE_BOOKS, null);
    }

    //receives the word that the user wants to search of the book
    public Cursor searchBook(String search){
        //open the db jsut for searching
        SQLiteDatabase db = this.getReadableDatabase();

        //this means that it finds the records in the db and find that it matches what the user search for
        return db.rawQuery("SELECT * FROM " + TABLE_BOOKS + " WHERE " + COLUMN_BOOK + " LIKE? ",  new String[]{
                "%" + search + "%"});   //at the middle thats the input u search, and if the book is successfully found, then it will display
                //it means %Java%
    }
}


//goal in this database is to talk with sqlite and give it commands and stores the info in this database